   function y = simple_multiobjective(x)
   y(1) = (x+2)^2 - 10;
   y(2) = (x-2)^2 + 20;
